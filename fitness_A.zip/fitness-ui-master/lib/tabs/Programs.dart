import 'package:fitness_flutter/components/daily_tip.dart';
import 'package:fitness_flutter/components/header.dart';
import 'package:fitness_flutter/components/image_card_with_basic_footer.dart';
import 'package:fitness_flutter/components/section.dart';
import 'package:fitness_flutter/components/image_card_with_internal.dart';
import 'package:fitness_flutter/components/user_photo.dart';
import 'package:fitness_flutter/components/user_tip.dart';
import 'package:fitness_flutter/models/exercise.dart';
import 'package:fitness_flutter/pages/activity_detail.dart';
import 'package:flutter/material.dart';

class Programs extends StatelessWidget {
  final List<Exercise> exercises = [
    Exercise(
      image: 'assets/images/image001.jpg',
      title: 'Beginner ',
      time: '5 min',
      difficult: 'Low',
    ),
    Exercise(
      image: 'assets/images/image002.jpg',
      title: 'Intermediate ',
      time: '10 min',
      difficult: 'Medium',
    ),
    Exercise(
      image: 'assets/images/image003.jpg',
      title: 'Advanced',
      time: '25 min',
      difficult: 'High',
    )
  ];

  List<Widget> generateList(BuildContext context) {
    List<Widget> list = [];
    int count = 0;
    exercises.forEach((exercise) {
      Widget element = Container(
        margin: EdgeInsets.only(right: 20.0),
        child: GestureDetector(
          child: ImageCardWithBasicFooter(
            exercise: exercise,
            tag: 'imageHeader$count',
          ),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) {
                  return ActivityDetail(
                    exercise: exercise,
                    tag: 'imageHeader$count',
                  );
                },
              ),
            );
          },
        ),
      );
      list.add(element);
      count++;
    });
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: SafeArea(
          child: Container(
            padding: EdgeInsets.only(top: 20.0),
            child: Column(
              children: <Widget>[
                Header(
                  'Fitness-Up',
                  rightSide: UserPhoto(),
                ),
               // MainCardPrograms(), // MainCard
                Section(
                  title: 'Fat burning',
                  horizontalList: this.generateList(context),
                ),
                Section(
                  title: 'Abs Generating',
                  horizontalList: <Widget>[
                    ImageCardWithInternal(
                      image: 'assets/images/P.jfif',
                      title: 'Pre-Workout',
                      duration: '5 min',
                    ),
                    ImageCardWithInternal(
                      image: 'assets/images/Streching.jpg',
                      title: 'streching',
                      duration: '3 min',
                    ),
                    ImageCardWithInternal(
                      image: 'assets/images/image004.jpg',
                      title: 'Core \nWorkout',
                      duration: '15 min',
                    ),
                  ],
                ),
                Container(
                  margin: EdgeInsets.only(top: 50.0),
                  padding: EdgeInsets.only(top: 10.0, bottom: 40.0),
                  decoration: BoxDecoration(
                    color: Colors.blue[50],
                  ),
                  child: Column(
                    children: <Widget>[
                      Section(
                        title: 'Daily Tips',
                        horizontalList: <Widget>[
                          UserTip(
                            image: 'assets/images/G.png',
                            name: 'Gaurav Taneja',
                            url: 'https://www.thewikifeed.com/gaurav-taneja/',
                           ),
                          UserTip(
                            image: 'assets/images/S.png',
                            name: 'Sahil Khan',
                            url: 'https://en.wikipedia.org/wiki/Sahil_Khan',
                          ),
                          UserTip(
                            image: 'assets/images/SangramChougule.png',
                            name: 'SangramChougule',
                            url: 'https://en.wikipedia.org/wiki/Sangram_Chougule',
                          ),
                          UserTip(
                            image: 'assets/images/Suhas_Khamkar.png',
                            name: 'Suhas Khamkar',
                            url: 'https://en.wikipedia.org/wiki/Suhas_Khamkar',
                          ),
                        ],
                      ),
                      Section(
                        horizontalList: <Widget>[
                          DailyTip(),
                          // DailyTip(),
                          // DailyTip(),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
// class story extends StatefulWidget {
//   const story({Key key}) : super(key: key);
//
//   @override
//   _storyState createState() => _storyState();
// }
//
// class _storyState extends State<story> {
//   final controller =StoryController();
//   @override
//   Widget build(BuildContext context) {
//     return Material(
//       child: StoryView(
//         storyItems: [
//         StoryItem.pageImage(url:"https://www.instagram.com/stories/taneja.gaurav/2622733756976578542/?hl=en",controller:controller)
//         ],
//           controller: controller,
//         inline:false,
//         repeat:false
//       )
//     );
//   }
// }
